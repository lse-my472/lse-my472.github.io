pkgs <- c("openssl", "readr")
for (p in pkgs) {
    if (!requireNamespace(p, quietly = TRUE)) {
        install.packages(p, repos = "https://cloud.r-project.org")
    }
}
library("openssl")
library("readr")

# Where is the key?
key.path <- "~/.meu/meu.bin"

# Check if need to proceed
lpath <- file.path("~/Downloads", "test")
dpath <- "~/Desktop"

tpath <- file.path(dpath, "MY472-AT25-test.qmd")
rpath <- file.path(dpath, "resources")
epath <- file.path(dpath, "MY472-AT25-test.qmd.enc")

if(!dir.exists(lpath) & !file.exists(tpath)){
  stop("You have not downloaded the test folder or it is not in your Downloads folder!")
} else if(file.exists(tpath)) {
  stop("You already downloaded and decrypted the test!")
}

# Where are the files going
file.rename(gsub("Desktop", "Downloads/test", epath), epath)
file.rename(gsub("Desktop", "Downloads/test", rpath), rpath)

# Decrypt
if(file.exists(epath) & !file.exists(tpath)){
  data <- read_file_raw(epath)
  iv <- data[1:12]
  data <- data[13:length(data)]
  raw <- aes_gcm_decrypt(data,
                        key = read_file_raw(key.path),
                        iv = iv)
  write_file(raw, tpath)
  unlink(epath)
} else if(file.exists(tpath)){ 
  stop("You already downloaded and decrypted the test!")
} else {
  stop("Error! Cannot find the test!")
}